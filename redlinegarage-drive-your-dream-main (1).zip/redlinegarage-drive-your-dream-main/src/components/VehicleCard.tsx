import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

interface VehicleCardProps {
  image: string;
  name: string;
  type: string;
  engine: string;
  year: number;
  index: number;
}

const VehicleCard = ({ image, name, type, engine, year, index }: VehicleCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative bg-card rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all duration-500"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={`${name} - ${type}`}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-60" />
        
        {/* Glow Effect on Hover */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
          <div className="absolute inset-0 bg-primary/10" />
          <div className="absolute inset-x-0 bottom-0 h-1 bg-primary shadow-[0_0_20px_hsl(var(--primary))]" />
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <span className="text-xs text-primary uppercase tracking-wider font-medium">
              {type}
            </span>
            <h3 className="font-display text-xl text-foreground mt-1">
              {name}
            </h3>
          </div>
          <span className="text-muted-foreground text-sm">{year}</span>
        </div>

        <p className="text-muted-foreground text-sm mb-4">
          {engine}
        </p>

        <Button
          variant="vehicle"
          size="sm"
          className="w-full"
        >
          View Details
        </Button>
      </div>
    </motion.div>
  );
};

export default VehicleCard;