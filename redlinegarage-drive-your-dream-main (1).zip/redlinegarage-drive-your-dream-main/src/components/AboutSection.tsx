import { motion } from "framer-motion";
import { Award, Users, Wrench, Shield } from "lucide-react";

const stats = [
  { icon: Award, value: "15+", label: "Years Experience" },
  { icon: Users, value: "5000+", label: "Happy Clients" },
  { icon: Wrench, value: "200+", label: "Vehicles Delivered" },
  { icon: Shield, value: "100%", label: "Quality Guaranteed" },
];

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-secondary">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary text-sm uppercase tracking-widest font-medium">
              About Us
            </span>
            <h2 className="font-display text-4xl md:text-5xl mt-4 mb-6">
              Passion Meets <span className="text-primary">Performance</span>
            </h2>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              At RedLineGarage, we're more than just a dealership – we're enthusiasts who understand the thrill of the open road. Our journey began with a simple passion: connecting people with their dream machines.
            </p>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Every vehicle in our collection is meticulously curated to meet the highest standards of performance, style, and reliability. We believe that owning a great car or bike isn't just about transportation – it's about making a statement.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-display text-2xl text-foreground">
                      {stat.value}
                    </div>
                    <div className="text-muted-foreground text-sm">
                      {stat.label}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Visual Element */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-square rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-primary/10" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="font-display text-8xl md:text-9xl text-primary/20">
                    RLG
                  </div>
                  <div className="font-display text-xl md:text-2xl tracking-widest text-foreground mt-4">
                    <span className="text-primary">Red</span>Line
                    <span className="text-muted-foreground">Garage</span>
                  </div>
                </div>
              </div>
              {/* Decorative Elements */}
              <div className="absolute top-10 right-10 w-20 h-20 border border-primary/30 rounded-full" />
              <div className="absolute bottom-10 left-10 w-32 h-32 border border-primary/20 rounded-full" />
              <div className="absolute top-1/3 left-1/4 w-2 h-2 bg-primary rounded-full animate-pulse" />
              <div className="absolute bottom-1/3 right-1/4 w-3 h-3 bg-primary/50 rounded-full animate-pulse" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;