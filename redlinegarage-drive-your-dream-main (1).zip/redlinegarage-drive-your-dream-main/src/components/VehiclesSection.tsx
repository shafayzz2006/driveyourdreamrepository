import { motion } from "framer-motion";
import VehicleCard from "./VehicleCard";
import vehicleBike from "@/assets/vehicle-bike.jpg";
import vehicleCarRed from "@/assets/vehicle-car-red.jpg";
import vehicleSuv from "@/assets/vehicle-suv.jpg";
import vehicleMuscle from "@/assets/vehicle-muscle.jpg";
import vehicleBikeRed from "@/assets/vehicle-bike-red.jpg";
import heroCar from "@/assets/hero-car.jpg";

const vehicles = [
  {
    image: vehicleCarRed,
    name: "Inferno GT",
    type: "Sports Car",
    engine: "4.0L V8 Twin-Turbo • 720 HP",
    year: 2024,
  },
  {
    image: vehicleBike,
    name: "Shadow Fury",
    type: "Sport Bike",
    engine: "1000cc Inline-4 • 200 HP",
    year: 2024,
  },
  {
    image: vehicleSuv,
    name: "Titan X",
    type: "Luxury SUV",
    engine: "3.0L V6 Hybrid • 450 HP",
    year: 2024,
  },
  {
    image: vehicleMuscle,
    name: "Venom 440",
    type: "Muscle Car",
    engine: "6.2L V8 Supercharged • 650 HP",
    year: 2024,
  },
  {
    image: vehicleBikeRed,
    name: "Diavolo RS",
    type: "Superbike",
    engine: "1199cc L-Twin • 214 HP",
    year: 2024,
  },
  {
    image: heroCar,
    name: "Phantom Black",
    type: "Grand Tourer",
    engine: "5.0L V8 • 580 HP",
    year: 2024,
  },
];

const VehiclesSection = () => {
  return (
    <section id="vehicles" className="section-padding bg-background">
      <div className="container-custom">
        {/* Section Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm uppercase tracking-widest font-medium">
            Our Collection
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl mt-4 mb-6">
            Featured <span className="text-primary">Vehicles</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our handpicked selection of premium cars and bikes. Each machine represents the pinnacle of automotive engineering and design.
          </p>
        </motion.div>

        {/* Vehicle Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {vehicles.map((vehicle, index) => (
            <VehicleCard key={vehicle.name} {...vehicle} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default VehiclesSection;