import { useEffect } from "react";
import { motion } from "framer-motion";

interface LoadingScreenProps {
  onComplete: () => void;
}

const LoadingScreen = ({ onComplete }: LoadingScreenProps) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Spinning Wheel */}
      <div className="relative mb-8">
        <svg
          className="animate-spin-wheel w-24 h-24 md:w-32 md:h-32"
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer tire */}
          <circle
            cx="50"
            cy="50"
            r="45"
            stroke="hsl(var(--muted))"
            strokeWidth="8"
          />
          {/* Inner rim */}
          <circle
            cx="50"
            cy="50"
            r="35"
            stroke="hsl(var(--primary))"
            strokeWidth="3"
          />
          {/* Hub */}
          <circle
            cx="50"
            cy="50"
            r="10"
            fill="hsl(var(--primary))"
          />
          {/* Spokes */}
          {[0, 60, 120, 180, 240, 300].map((angle, i) => (
            <line
              key={i}
              x1="50"
              y1="50"
              x2={50 + 30 * Math.cos((angle * Math.PI) / 180)}
              y2={50 + 30 * Math.sin((angle * Math.PI) / 180)}
              stroke="hsl(var(--muted-foreground))"
              strokeWidth="3"
            />
          ))}
          {/* Tire treads */}
          {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((angle, i) => (
            <line
              key={`tread-${i}`}
              x1={50 + 41 * Math.cos((angle * Math.PI) / 180)}
              y1={50 + 41 * Math.sin((angle * Math.PI) / 180)}
              x2={50 + 49 * Math.cos((angle * Math.PI) / 180)}
              y2={50 + 49 * Math.sin((angle * Math.PI) / 180)}
              stroke="hsl(var(--muted-foreground))"
              strokeWidth="2"
            />
          ))}
        </svg>
      </div>

      {/* Brand Name */}
      <motion.h1
        className="font-display text-3xl md:text-4xl tracking-wider mb-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <span className="text-primary">Red</span>
        <span className="text-foreground">Line</span>
        <span className="text-muted-foreground">Garage</span>
      </motion.h1>

      {/* Tagline */}
      <motion.p
        className="text-muted-foreground text-sm md:text-base tracking-widest uppercase"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        Revving Up Your Experience...
      </motion.p>
    </motion.div>
  );
};

export default LoadingScreen;